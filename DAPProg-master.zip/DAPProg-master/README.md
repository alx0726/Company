# DAPProg
Offline SWD Programmer for Cortex-M Core MCU

This Project bases on some other open-source Project:

1、file under src/DAP and file SWD_host.c come form [ARMmbed/DAPLink](https://github.com/ARMmbed/DAPLink)

2、file /doc/FlashAlgo/flash_algo.py come from [mbedmicro/FlashAlgo](https://github.com/mbedmicro/FlashAlgo)

flash_algo.py is used to extracting flash programming code from Keil's *.FLM algorithm file
